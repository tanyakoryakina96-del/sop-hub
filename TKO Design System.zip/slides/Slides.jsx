/* global React */
function TitleSlide({ eyebrow='Supply chain AI · 2025', title, subtitle, author='Tatiana · Bluecrux' }) {
  return (
    <div className="slide slide-title">
      <div className="accent-bar" />
      <div className="eyebrow">{eyebrow}</div>
      <div className="title">{title}</div>
      {subtitle && <div className="subtitle">{subtitle}</div>}
      <div className="sig-row">
        <div className="avatar">TK</div>
        <div className="sig">{author}</div>
      </div>
    </div>
  );
}
function StatSlide({ label, number, caption, footnote }) {
  return (
    <div className="slide slide-stat">
      <div className="accent-bar" />
      <div className="eyebrow">{label}</div>
      <div className="stat-number">{number}</div>
      <div className="stat-caption">{caption}</div>
      {footnote && <div className="footnote">{footnote}</div>}
    </div>
  );
}
function BulletsSlide({ label, title, points }) {
  return (
    <div className="slide slide-bullets">
      <div className="accent-bar" />
      <div className="eyebrow">{label}</div>
      <div className="h2">{title}</div>
      <div className="bullets">
        {points.map((p,i)=>(
          <div key={i} className="bullet"><div className="dot" /><div className="b-text">{p}</div></div>
        ))}
      </div>
    </div>
  );
}
function QuoteSlide({ quote, source }) {
  return (
    <div className="slide slide-quote">
      <div className="q-mark">"</div>
      <div className="q-text">{quote}</div>
      <div className="q-source">{source}</div>
    </div>
  );
}
function ComparisonSlide({ label, title, left, right }) {
  return (
    <div className="slide slide-compare">
      <div className="accent-bar" />
      <div className="eyebrow">{label}</div>
      <div className="h2">{title}</div>
      <div className="compare-grid">
        <div className="c-col c-left">
          <div className="c-head">{left.head}</div>
          <div className="c-body">{left.body}</div>
        </div>
        <div className="c-col c-right">
          <div className="c-head c-head-acid">{right.head}</div>
          <div className="c-body">{right.body}</div>
        </div>
      </div>
    </div>
  );
}
function CoverSlide() {
  return (
    <div className="slide slide-cover">
      <div className="cover-grid" />
      <div className="cover-inner">
        <div className="eyebrow" style={{color:'#818CF8'}}>A series by Tatiana Koriakina</div>
        <div className="cover-title">AI in<br/>Supply Chain</div>
        <div className="cover-sub">The parts nobody posts about · 2025</div>
        <div className="cover-rule" />
        <div className="sig-row">
          <div className="avatar">TK</div>
          <div className="sig">Tatiana · Bluecrux</div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { TitleSlide, StatSlide, BulletsSlide, QuoteSlide, ComparisonSlide, CoverSlide });
