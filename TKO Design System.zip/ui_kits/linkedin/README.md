# LinkedIn UI Kit — TKO

A high-fidelity recreation of Tatiana Koriakina's LinkedIn surface: profile header, feed, insight post, carousel, quote card, and composer. Components are cosmetic recreations — real enough to look finished, simple enough to be re-used as building blocks in other designs.

## Components

- `ProfileHeader.jsx` — banner + avatar + bio + metric row
- `FeedComposer.jsx` — "Start a post" composer with topic chips
- `InsightPost.jsx` — the canonical post format (accent bar, tag, headline, body, stat row, author)
- `CarouselSlide.jsx` — single slide of a LinkedIn carousel document
- `QuoteCard.jsx` — the left-border acid quote card
- `AuthorBlock.jsx` — reusable avatar + name + role
- `Tag.jsx`, `Chip.jsx`, `StatTile.jsx`, `Button.jsx` — primitives

## Entry
Open `index.html` — it boots a mini LinkedIn-like feed surface populated with Tatiana's content.

## Source
Everything here is derived from `../../uploads/TKO_Brand.html` (the source brand file). No Figma or codebase was provided.
