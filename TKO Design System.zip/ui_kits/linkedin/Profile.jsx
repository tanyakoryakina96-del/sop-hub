/* global React, Tag, Pill, Button, AuthorBlock */

function ProfileHeader({ onFollow, following=false }) {
  return (
    <div style={{
      background:'#0A0C14', borderRadius:14, overflow:'hidden',
      border:'0.5px solid #2A2D42', width:680
    }}>
      {/* Banner — plasma→acid with void fade */}
      <div style={{
        height:140, position:'relative',
        background:'linear-gradient(135deg,#0A0C14 0%,#13162A 40%,#6D28D9 130%)'
      }}>
        <div style={{
          position:'absolute', inset:0,
          background:'radial-gradient(circle at 85% 80%, rgba(200,224,0,0.25), transparent 55%)'
        }} />
        <div style={{ position:'absolute', left:24, top:20, color:'#E8EEFF',
          fontFamily:"'Barlow Condensed',sans-serif", fontSize:44, fontWeight:700,
          textTransform:'uppercase', letterSpacing:'0.02em', lineHeight:1 }}>
          AI · Supply Chain
        </div>
        <div style={{ position:'absolute', left:24, top:70,
          fontFamily:"'Inter',sans-serif", fontSize:11, color:'#818CF8',
          letterSpacing:'0.14em', textTransform:'uppercase', fontWeight:500 }}>
          Change management · Data readiness · ERP
        </div>
      </div>
      <div style={{ padding:'0 24px 20px', position:'relative' }}>
        <div style={{
          width:84, height:84, borderRadius:'50%',
          background:'linear-gradient(135deg,#6D28D9 0%,#818CF8 100%)',
          display:'flex', alignItems:'center', justifyContent:'center',
          color:'#E8EEFF', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700,
          fontSize:30, letterSpacing:'0.04em',
          border:'3px solid #0A0C14',
          marginTop:-42, marginBottom:12
        }}>TK</div>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
          <div>
            <div style={{
              fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, color:'#E8EEFF',
              fontSize:28, textTransform:'uppercase', letterSpacing:'0.02em', lineHeight:1
            }}>Tatiana Koriakina</div>
            <div style={{ fontSize:15, color:'#D4D8EE', marginTop:8, fontWeight:300, lineHeight:1.5, maxWidth:420 }}>
              Senior Consultant at Bluecrux — I write about what actually breaks in AI supply-chain rollouts.
            </div>
            <div style={{ display:'flex', gap:8, marginTop:12, flexWrap:'wrap' }}>
              <Tag>Supply chain AI</Tag>
              <Tag>Change management</Tag>
              <Tag>ERP & data</Tag>
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end' }}>
            <Button variant={following?'ghost':'primary'} onClick={onFollow}>
              {following?'Following ✓':'Follow'}
            </Button>
            <Button variant="ghost">Message</Button>
          </div>
        </div>
        <div style={{ display:'flex', gap:24, marginTop:20,
          borderTop:'0.5px solid #2A2D42', paddingTop:18 }}>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, color:'#C8E000', fontSize:26, lineHeight:1 }}>18.4k</div>
            <div style={{ fontSize:11, color:'#9098B8', letterSpacing:'0.14em', textTransform:'uppercase', fontWeight:500, marginTop:6 }}>Followers</div>
          </div>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, color:'#C8E000', fontSize:26, lineHeight:1 }}>127</div>
            <div style={{ fontSize:11, color:'#9098B8', letterSpacing:'0.14em', textTransform:'uppercase', fontWeight:500, marginTop:6 }}>Posts · 2025</div>
          </div>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, color:'#C8E000', fontSize:26, lineHeight:1 }}>3.2%</div>
            <div style={{ fontSize:11, color:'#9098B8', letterSpacing:'0.14em', textTransform:'uppercase', fontWeight:500, marginTop:6 }}>Engagement</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeedComposer({ onPost }) {
  const [text, setText] = React.useState('');
  const [topic, setTopic] = React.useState('Supply chain AI');
  const topics = ['Supply chain AI','Change management','Data readiness','ERP'];
  return (
    <div style={{
      background:'#0A0C14', borderRadius:14, padding:20, width:680,
      border:'0.5px solid #2A2D42'
    }}>
      <div style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
        <div style={{
          width:40, height:40, borderRadius:'50%',
          background:'linear-gradient(135deg,#6D28D9 0%,#818CF8 100%)',
          display:'flex', alignItems:'center', justifyContent:'center',
          color:'#E8EEFF', fontFamily:"'Inter',sans-serif", fontWeight:500, fontSize:14, flexShrink:0
        }}>TK</div>
        <textarea
          value={text} onChange={e=>setText(e.target.value)}
          placeholder="Write something contrarian…"
          style={{
            flex:1, background:'#13162A', border:'0.5px solid #2A2D42', color:'#E8EEFF',
            padding:'12px 14px', borderRadius:10, fontFamily:"'Inter',sans-serif",
            fontWeight:300, fontSize:15, outline:'none', resize:'none', minHeight:60, lineHeight:1.55
          }}
        />
      </div>
      <div style={{ display:'flex', gap:8, marginTop:14, flexWrap:'wrap', alignItems:'center' }}>
        {topics.map(t => (
          <button key={t} onClick={()=>setTopic(t)}
            style={{
              background:'transparent', border:'none', padding:0, cursor:'pointer'
            }}>
            <Tag variant={topic===t ? 'indigo':'default'}>{t}</Tag>
          </button>
        ))}
        <div style={{ flex:1 }} />
        <Button
          variant="primary"
          disabled={!text.trim()}
          onClick={() => { if (text.trim()) { onPost({ text, topic }); setText(''); } }}
        >Post</Button>
      </div>
    </div>
  );
}

Object.assign(window, { ProfileHeader, FeedComposer });
