/* global React, Tag, StatTile, AuthorBlock */

function InsightPost({ tag='Supply chain AI', headline, body, stats=[], onLike, liked=false, likes=0, comments=0 }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background:'#0A0C14', borderRadius:14, padding:22, width:460,
        position:'relative', overflow:'hidden',
        border:`0.5px solid ${hover?'#3A4060':'#2A2D42'}`,
        transition:'border-color 180ms cubic-bezier(0.2,0.8,0.2,1)'
      }}>
      <div style={{ position:'absolute', top:0, left:0, right:0, height:2,
        background:'linear-gradient(90deg,#6D28D9 0%,#C8E000 100%)' }} />
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <AuthorBlock size="sm" />
        <Tag>{tag}</Tag>
      </div>
      <div style={{
        fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, textTransform:'uppercase',
        letterSpacing:'0.01em', color:'#E8EEFF', fontSize:26, lineHeight:1.15, margin:'16px 0 12px'
      }}>{headline}</div>
      <div style={{ fontSize:14, lineHeight:1.65, color:'#B8BED8', fontWeight:300 }}>{body}</div>
      {stats.length > 0 && (
        <div style={{ display:'flex', gap:10, marginTop:18 }}>
          {stats.map((s,i) => <StatTile key={i} value={s.value} label={s.label} />)}
        </div>
      )}
      <div style={{ borderTop:'0.5px solid #2A2D42', margin:'18px 0 14px' }} />
      <div style={{ display:'flex', alignItems:'center', gap:18, fontFamily:"'Inter',sans-serif" }}>
        <button onClick={onLike} style={{
          background:'transparent', border:'none', cursor:'pointer', padding:0,
          color: liked ? '#C8E000' : '#9098B8', fontSize:12, fontWeight:500,
          letterSpacing:'0.14em', textTransform:'uppercase', display:'flex', alignItems:'center', gap:6
        }}>
          <span style={{ fontSize:14 }}>{liked?'●':'○'}</span> Like · {likes}
        </button>
        <button style={{
          background:'transparent', border:'none', cursor:'pointer', padding:0,
          color:'#9098B8', fontSize:12, fontWeight:500,
          letterSpacing:'0.14em', textTransform:'uppercase'
        }}>Comment · {comments}</button>
        <button style={{
          background:'transparent', border:'none', cursor:'pointer', padding:0,
          color:'#9098B8', fontSize:12, fontWeight:500,
          letterSpacing:'0.14em', textTransform:'uppercase', marginLeft:'auto'
        }}>Repost</button>
      </div>
    </div>
  );
}

function QuoteCard({ quote, source }) {
  return (
    <div style={{
      background:'#13162A', borderRadius:14, padding:24, width:420,
      borderLeft:'2px solid #C8E000',
      borderTop:'0.5px solid #2A2D42', borderRight:'0.5px solid #2A2D42', borderBottom:'0.5px solid #2A2D42'
    }}>
      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700,
        color:'#C8E000', fontSize:44, lineHeight:0.7, marginBottom:14 }}>"</div>
      <div style={{
        fontFamily:"'Barlow Condensed',sans-serif", fontWeight:600, textTransform:'uppercase',
        letterSpacing:'0.01em', color:'#E8EEFF', fontSize:18, lineHeight:1.4, margin:'0 0 16px'
      }}>{quote}</div>
      <div style={{ fontSize:11, color:'#9098B8', fontFamily:"'Inter',sans-serif",
        letterSpacing:'0.14em', fontWeight:500, textTransform:'uppercase' }}>{source}</div>
    </div>
  );
}

function CarouselSlide({ number, total, label, title, points, active=0, onNext, onPrev }) {
  return (
    <div style={{
      background:'#13162A', borderRadius:14, padding:24, width:420,
      border:'0.5px solid #2A2D42', userSelect:'none'
    }}>
      <div style={{ fontSize:11, fontWeight:500, color:'#818CF8', letterSpacing:'0.14em',
        fontFamily:"'Inter',sans-serif", textTransform:'uppercase' }}>
        {String(number).padStart(2,'0')} / {String(total).padStart(2,'0')} · {label}
      </div>
      <div style={{
        fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, color:'#E8EEFF',
        fontSize:24, lineHeight:1.2, margin:'14px 0 20px', textTransform:'uppercase',
        letterSpacing:'0.02em'
      }}>{title}</div>
      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {points.map((p,i) => (
          <div key={i} style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background:'#C8E000', marginTop:7, flexShrink:0, boxShadow:'0 0 8px rgba(200,224,0,0.4)' }} />
            <div style={{ fontSize:14, color:'#B8BED8', lineHeight:1.5, fontWeight:300 }}>{p}</div>
          </div>
        ))}
      </div>
      <div style={{ display:'flex', gap:4, marginTop:24 }}>
        {Array.from({length:total}).map((_,i) => (
          <div key={i} style={{ height:2, borderRadius:1, flex:1, background: i===active ? '#C8E000' : '#2A2D42' }} />
        ))}
      </div>
      {(onPrev || onNext) && (
        <div style={{ display:'flex', justifyContent:'space-between', marginTop:16 }}>
          <button onClick={onPrev} style={{ background:'transparent', border:'none', color:'#9098B8',
            fontSize:11, letterSpacing:'0.14em', textTransform:'uppercase', fontWeight:500, cursor:'pointer', padding:0 }}>← Prev</button>
          <button onClick={onNext} style={{ background:'transparent', border:'none', color:'#818CF8',
            fontSize:11, letterSpacing:'0.14em', textTransform:'uppercase', fontWeight:500, cursor:'pointer', padding:0 }}>Next →</button>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { InsightPost, QuoteCard, CarouselSlide });
