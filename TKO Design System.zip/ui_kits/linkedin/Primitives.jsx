/* global React */
const { useState } = React;

function Tag({ children, variant = 'default' }) {
  const styles = {
    default: { bg:'#1E2235', fg:'#818CF8', border:'#2D3352' },
    acid:    { bg:'#1A1D2E', fg:'#C8E000', border:'#C8E000' },
    indigo:  { bg:'#1A1D2E', fg:'#818CF8', border:'#818CF8' },
    mute:    { bg:'#1A1D2E', fg:'#4A506E', border:'#2A2D42' },
  }[variant];
  return (
    <span style={{
      fontSize:10, padding:'3px 10px', borderRadius:3,
      background:styles.bg, color:styles.fg, border:`0.5px solid ${styles.border}`,
      letterSpacing:'0.14em', fontWeight:500, textTransform:'uppercase',
      fontFamily:"'Inter', sans-serif", display:'inline-block', whiteSpace:'nowrap'
    }}>{children}</span>
  );
}

function Pill({ children, variant='default' }) {
  const styles = {
    default: { bg:'#1A1D2E', fg:'#818CF8', border:'#818CF8' },
    acid:    { bg:'#1A1D2E', fg:'#C8E000', border:'#C8E000' },
    mute:    { bg:'#1A1D2E', fg:'#4A506E', border:'#2A2D42' },
  }[variant];
  return (
    <span style={{
      fontSize:10, padding:'4px 12px', borderRadius:20,
      background:styles.bg, color:styles.fg, border:`0.5px solid ${styles.border}`,
      letterSpacing:'0.08em', fontWeight:500, textTransform:'uppercase',
      fontFamily:"'Inter', sans-serif", display:'inline-block'
    }}>{children}</span>
  );
}

function Button({ children, variant='primary', onClick, disabled, style={} }) {
  const base = {
    border:'none', padding:'12px 20px', borderRadius:10,
    fontFamily:"'Barlow Condensed', sans-serif", fontWeight:700, textTransform:'uppercase',
    letterSpacing:'0.08em', fontSize:12, cursor:'pointer',
    transition:'all 160ms cubic-bezier(0.2,0.8,0.2,1)'
  };
  const v = {
    primary: { background:'#C8E000', color:'#0A0C14' },
    plasma:  { background:'#6D28D9', color:'#E8EEFF' },
    ghost:   { background:'transparent', color:'#E8EEFF', border:'0.5px solid #2A2D42' },
    text:    { background:'transparent', color:'#818CF8', padding:'12px 14px',
               fontFamily:"'Inter',sans-serif", letterSpacing:'0.14em', fontSize:10 },
  }[variant];
  return (
    <button onClick={onClick} disabled={disabled}
      style={{...base, ...v, ...(disabled?{opacity:.4, cursor:'not-allowed'}:null), ...style}}>
      {children}
    </button>
  );
}

function StatTile({ value, label }) {
  return (
    <div style={{ background:'#13162A', borderRadius:8, padding:'12px 14px', flex:1, border:'0.5px solid #2A2D42' }}>
      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, color:'#C8E000', fontSize:24, lineHeight:1, letterSpacing:'0.02em' }}>{value}</div>
      <div style={{ fontSize:12, color:'#9098B8', marginTop:6, lineHeight:1.4, fontWeight:300 }}>{label}</div>
    </div>
  );
}

function AuthorBlock({ initials='TK', name='Tatiana Koriakina', role='Senior Consultant · Bluecrux', size='md' }) {
  const s = size==='sm' ? { av:32, avF:12, nameF:13, roleF:12 } : { av:40, avF:14, nameF:15, roleF:13 };
  return (
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <div style={{
        width:s.av, height:s.av, borderRadius:'50%',
        background:'linear-gradient(135deg,#6D28D9 0%,#818CF8 100%)',
        display:'flex', alignItems:'center', justifyContent:'center',
        color:'#E8EEFF', fontFamily:"'Inter',sans-serif", fontWeight:500, fontSize:s.avF, flexShrink:0
      }}>{initials}</div>
      <div>
        <div style={{ fontSize:s.nameF, fontWeight:500, color:'#E8EEFF' }}>{name}</div>
        <div style={{ fontSize:s.roleF, color:'#9098B8', fontWeight:300 }}>{role}</div>
      </div>
    </div>
  );
}

Object.assign(window, { Tag, Pill, Button, StatTile, AuthorBlock });
