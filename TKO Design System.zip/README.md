# TKO Design System

**Tatiana Koriakina — Personal Brand on LinkedIn**
_AI in Supply Chain · Senior Consultant · Bluecrux_

A dark, signal-driven personal brand system built around the palette **Void + Plasma + Acid**. Used for LinkedIn posts, carousels, quote cards, and short-form slide decks on topics like data readiness, ERP rollouts, demand planning, and change management in AI-enabled supply chains.

## Source materials

- `uploads/TKO_Brand.html` — the original brand palette file with swatches, type scale, and three LinkedIn post format mocks (insight post + stats, carousel slide, quote card). This is the sole source of truth for the system.

No codebase, Figma file, or additional assets were provided. Everything in this system is derived from the single HTML brand document above, with logical extensions (semantic tokens, additional components) layered on top.

---

## Index

```
/README.md                ← this file
/SKILL.md                 ← skill manifest (for Claude Code + preview)
/colors_and_type.css      ← design tokens: color + type + spacing + motion
/fonts/                   ← webfonts (Google Fonts CDN — see note)
/assets/                  ← logos, generic visuals
/preview/                 ← design-system cards (Colors / Type / Spacing / Components / Brand)
/ui_kits/
  /linkedin/              ← LinkedIn post + carousel + profile surface
    index.html
    *.jsx
/slides/                  ← 16:9 slide templates matching the brand
    index.html
    *.jsx
```

---

## CONTENT FUNDAMENTALS

Tatiana's LinkedIn voice is **the sharp consultant**: short, confident, contrarian. She punctures the hype around enterprise AI by pointing at what actually breaks — the data layer, the change-management layer, the ERP substrate underneath. The reader is a fellow operator: a head of supply chain, a planning lead, a CIO.

### Voice & tone

- **Declarative, not hedged.** Sentences end early. "Most AI pilots fail before they start." "Your ERP is not your data foundation."
- **Contrarian hook → evidence → takeaway.** Open with a claim that rubs against conventional wisdom, then substantiate with a number or a specific operational detail.
- **No fluff adjectives.** Avoid "exciting," "incredible," "game-changing." If something is meaningful, the number says so.
- **Respect the reader.** No explainers on what AI is. Jargon like "SKU-level granularity," "monthly buckets," "demand signal" is used without definition — the audience has it.

### Grammatical conventions

- **Case** — display headings are **ALL CAPS** (Barlow Condensed). Body copy is sentence case. Labels are `UPPERCASE WITH TRACKING`. Never Title Case marketing-speak.
- **Person** — mostly second-person ("your ERP," "your data") with occasional third-person observations ("most teams…"). First-person ("I") appears rarely and only for credibility ("I've seen this in three rollouts this year").
- **Numbers as signal** — percentages, multipliers (4×), and counts carry the argument. They always render in Acid and in Barlow Condensed. Use them sparingly so they keep their weight.
- **No emoji.** None. The palette does the work.
- **No exclamation marks.** Tone is cool and assertive, not animated.
- **Sparing Oxford commas, sparing em-dashes.** Punctuation is utilitarian.

### Copy examples (from the source)

- Headline: **"Most AI pilots fail before they start."**
- Subhead: _"The bottleneck isn't the model. It's the data beneath it. Here's what clean demand signal actually looks like."_
- Label: `CHANGE MANAGEMENT · 2025`
- Carousel title: **"Three signs your data isn't AI-ready"**
- Quote: **"Change management isn't the soft part of an ERP rollout. It's the part that determines whether the hard part was worth it."**
- Signature block: `TATIANA · BLUECRUX · 2025`

### Length discipline

- LinkedIn post headline: 5–10 words.
- Post body: 2–4 short sentences, ~250–350 chars.
- Carousel slide: title ≤ 8 words, 2–4 bullets of ≤ 14 words each.
- Quote card: one sentence, ≤ 30 words.

---

## VISUAL FOUNDATIONS

### Palette — Void + Plasma + Acid

Three distinct layers, each with a job. Never blend the roles.

| Role | Token | Hex | Use |
|---|---|---|---|
| Deep background | `--void` | `#0A0C14` | Canvas, post backgrounds, dominant field |
| Surface 1 | `--graphite` | `#13162A` | Cards, quote cards, carousel surface |
| Surface 2 / border | `--cold-slate` | `#1E2235` | Chip fill, hairlines, stat tile bg |
| Border stronger | `--slate-mid` | `#2A2D42` | Emphasised divider |
| **Accent — structure** | `--plasma` | `#6D28D9` | Avatars, gradient start, selection |
| Accent — labels | `--neon-indigo` | `#818CF8` | Tags, `t-label-accent`, links |
| **SIGNAL** | `--acid` | `#C8E000` | Numbers, highlights, left-border on quotes, active pip |
| Primary text | `--ice-white` | `#E8EEFF` | Headlines + primary text |
| Body / muted | `--mist` | `#7880A0` | Body copy |
| Meta / caption | `--fog` | `#4A506E` | Labels, author-role, swatch labels |

**Acid is the signal colour.** It appears on numbers, highlights, and moments that demand attention. One acid element per card is the norm. Two is the ceiling. Never use acid for body copy or decoration.

### Typography

- **Display** — Barlow Condensed 700, UPPERCASE, `letter-spacing: 0.02em`. Headlines, stats, quote copy.
- **Body** — Inter 300 (light). Soft, low-contrast body copy against dark surfaces.
- **Labels** — Inter 500 UPPERCASE, `letter-spacing: 0.14em`. Tags, section markers, signatures.

The contrast between condensed-bold display and airy light body is the core type rhythm. Don't swap in a regular-width display or a heavy body — both break the vibe.

### Spacing & layout

- **4px baseline.** Common gaps: 8, 12, 14, 16, 22, 24, 32.
- **Card inner padding:** 22–24px. Cards feel dense, not airy.
- **Outer gap between previews:** 16px.
- **Post card max width:** ~260px (LinkedIn feed-optimised).

### Backgrounds

- **Flat void** is default. No full-bleed photography, no stock imagery, no hand-drawn illustrations.
- **Gradients** appear exclusively as:
  - A 2px top accent bar on hero cards (`plasma → acid`).
  - A 135° plasma→indigo fill for avatars and occasional feature surfaces.
- **No textures, no noise, no grain, no patterns.** The palette is the texture.

### Borders

- Default border weight is **0.5px hairline** (`--bw-hair`). This is signature — it's what makes cards feel precise and instrument-panel-like at small sizes.
- Accent stripes (top bar on posts, left bar on quote cards) are **2px**.
- Border colour is almost always `--cold-slate` (`#1E2235`) so the border reads as a suggestion, not an outline.

### Shadows & elevation

- Dark-mode restrained. Default card shadow is near-invisible (`0 6px 24px rgba(0,0,0,0.35)` with a 1px inner highlight).
- For "pop" moments, a plasma glow (`0 10px 40px rgba(109,40,217,0.25)`) or acid glow (`0 0 24px rgba(200,224,0,0.25)`) — used at most once per composition, normally on CTAs or active states.
- **No drop shadows on text.** Ever.

### Corner radii

- Tags / inline chips: **3px** (`--r-sm`) — intentionally crisp.
- Stat tiles: **8px** (`--r-md`).
- Swatches / inputs: **10px** (`--r-lg`).
- Cards: **14px** (`--r-xl`) — signature.
- Pills: **20px** (`--r-pill`).

### Animation & motion

- **Easing:** `cubic-bezier(0.2, 0.8, 0.2, 1)` standard.
- **Durations:** 120ms (micro — hovers), 200ms (standard — state changes), 320ms (slow — section reveal).
- **What's allowed:** fades, subtle translates (≤4px), crossfades, progress pip advancement.
- **What's not:** bounces, spins, elastic overshoot, spring-physics, parallax. The brand is composed, not playful.

### Hover & press states

- **Hover** — background shifts from `--graphite` to `--cold-slate`, or text from `--mist` to `--ice-white`. Borders can warm toward `--slate-mid`. No opacity fades on interactive elements (opacity-fade reads as "disabled" here).
- **Press** — background darkens to `--void` with a `scale(0.98)` over 80ms. Acid/plasma accents dim to `--acid-dim` / `--plasma-dim`.
- **Focus** — 2px plasma outline offset 2px. Never remove focus rings.
- **Disabled** — 40% opacity + `pointer-events: none`. No greyed-out recolor; let the palette fall off.

### Transparency & blur

- Used sparingly. The only canonical uses:
  - Protection gradient (`--grad-void-fade`) at the bottom of scrollable content.
  - Modal/overlay background: `rgba(10,12,20,0.7)` + `backdrop-filter: blur(8px)`.
- No frosted-glass cards, no translucent chips. Elements are either on a surface or not.

### Imagery treatment

- The system treats its aesthetic field — not photography — as the image. If photography is required, it should be **monochrome cool**, tinted toward `--cold-slate`, with a subtle grain applied only at render-time. No warm tones, no sun-flare, no "office worker smiling" stock.

### Layout rules

- Posts and carousels are **fixed-width** (260px) so they read correctly in the LinkedIn feed without being responsive-stretched.
- Slides are **16:9 fixed (1920×1080)** with a generous void margin — content sits in an ~1600×860 inner frame.
- Grids are sparse. Two columns max inside a card. Use whitespace, not dividers, to group.

---

## ICONOGRAPHY

The source brand document contains **no icons** — none. Composition relies on:

- Typography (all-caps display for emphasis).
- Colour (acid numbers, plasma avatars).
- Geometric primitives (2px accent bars, 5px acid dots for bullets, 2px progress pips, circular avatars).
- Initials-in-a-circle for author identification (e.g. "TK" on a plasma avatar).

**Emoji:** never.
**Unicode glyphs:** only the middle-dot `·` (U+00B7) as a separator in labels ("TATIANA · BLUECRUX · 2025"), and a straight typographic quote `"` rendered large and acid-coloured on quote cards.
**SVG usage:** reserved for the TKO monogram logo (`assets/tko-monogram.svg`) and the plasma↔acid token illustration (`assets/signal-token.svg`). Avoid introducing decorative SVG — the brand is minimal by design.

### When a real icon is needed

If a production design genuinely needs iconography (e.g. a UI surface with nav), use **Lucide Icons** (CDN: `https://unpkg.com/lucide-static`) at 16px or 20px, `stroke-width: 1.25`, colour `--fog` default and `--neon-indigo` on active. Lucide's thin, rationalist stroke matches the brand's restraint. **Flag the substitution in any deliverable** — the brand has no official icon set, so anything icon-bearing is an extension.

---

## Font substitution note

⚠️ **Barlow Condensed** and **Inter** are loaded from the Google Fonts CDN (referenced in `colors_and_type.css`). No bespoke `.ttf`/`.woff2` files were provided in the upload. These are the originals, not substitutions — Barlow Condensed is by Jeremy Tribby / Google, and Inter is by Rasmus Andersson — so the brand identity is preserved.

If you want self-hosted font files in `fonts/` (for offline builds or Claude Code exports), please upload the `.woff2` files and I'll wire them into `@font-face` declarations.

---

## SKILL.md

See `SKILL.md` for the Claude-Code-compatible skill manifest. It points agents back to this README as the entry point.
