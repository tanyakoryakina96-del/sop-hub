---
name: tko-design
description: Use this skill to generate well-branded interfaces and assets for Tatiana Koriakina's personal LinkedIn brand (AI in Supply Chain, Bluecrux senior consultant), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Aesthetic is dark, precise, signal-driven — "Void + Plasma + Acid".
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key files to explore:
- `README.md` — brand voice, content fundamentals, visual foundations, iconography
- `colors_and_type.css` — the source of truth for every token
- `ui_kits/linkedin/` — LinkedIn post, carousel, quote card, profile surface
- `slides/` — 16:9 slide templates
- `preview/` — design-system cards (Colors / Type / Spacing / Components / Brand)
- `assets/` — logo monogram, generic signal tokens

Non-negotiables:
- ALL-CAPS Barlow Condensed for display; Inter 300 for body.
- Acid `#C8E000` is for numbers, highlights, and signal only — never body copy.
- No emoji, no stock photography, no decorative SVG, no gradients except the 2px plasma→acid accent bar and the 135° plasma→indigo avatar fill.
- Cards use 0.5px hairline borders in `--cold-slate` and 14px corner radius.
- Voice is declarative, contrarian, numbers-driven. No hedging, no exclamation marks, no "exciting."
